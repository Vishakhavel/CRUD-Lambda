#importing necessary modules
import pymysql
import sys
import json

#RDS CREDENTIALS
rds_host  = "ENTER RDS HOST ENDPOINT"
username_db = "RDS USERNAME"
password_db = "RDS PASSWORD"
db_name = "DATABASE NAME. THIS IS THE DATABASE NAME YOU INITIALIZED, NOT THE DATABASE IDENTIFIER YOU MENTIONED IN THE RDS CONSOLE"

#CONNECTION OUTSIDE THE LAMBDA HANDLER TO AVOID THE EXTRA COST OF CONNECTION ON EVERY TRIGGER.
connection = pymysql.connect(rds_host, user=username_db, passwd=password_db, db=db_name, connect_timeout=5)

#DEFINING THE ENDPOINTS

GET_RAW_PATH = "/getUsers"
POST_RAW_PATH = "/createUser"
DELETE__RAW_PATH ="/deleteUser"
UPDATE_RAW_PATH = "/modifyUser"
LOGIN_RAW_PATH = "/login"
    
def lambda_handler(event, context):
    cursor = connection.cursor()
    
    if event['rawPath'] == GET_RAW_PATH:
        
        try:
            cursor.execute('SELECT * FROM USERS')
            rows = cursor.fetchall()
            getdata = json.dumps(rows)
            return {
                'statusCode' : 200,
                'body': getdata
            }
        
        except:
            return {
                'statusCode' : 200,
                'body': "Oops! Looks like something went wrong!"
            }
        
    elif event['rawPath'] == POST_RAW_PATH:
        
        username_data = event['queryStringParameters']['username']
        name_data = event['queryStringParameters']['name']
        email_data = event['queryStringParameters']['email']
        password_data = event['queryStringParameters']['password']
       
        try:
            cursor.execute("INSERT INTO USERS VALUES (%s, %s, %s, %s)", (name_data, email_data, username_data, password_data))
            
            return_string = "Welcome " + name_data + "!"
            return {
                'statusCode' : 200,
                'body': return_string
            }
            
        except:
            return {
                'statusCode' : 200,
                'body': "Could not create user because the EMAIL ID you have entered has already been taken! Try again with a different EMAIL ID."
            }
        
    elif event['rawPath'] == DELETE__RAW_PATH:
        
        try:
        
            email_data = event['queryStringParameters']['email']
            #email_data=email_data[0]
            
            cursor.execute("SELECT username FROM USERS WHERE email = (%s) ", (email_data))
            name_data = cursor.fetchall()
            name_data= name_data[0][0]
            
            print("THIS IS THE USERNAME RETURNED FROM DATABASE", name_data)
            cursor.execute("DELETE FROM USERS WHERE email = (%s) ", (email_data))
            
            return_string = "Deleted "+name_data+"'s account!"
            return {
                'statusCode' : 200,
                'body': return_string
            }
       
        except:
            return{
                "statusCode": 200,
                "body": "Please check the EMAIL ID again. The EMAIL ID is either - Not present or incorrect."
            }
        
    elif event['rawPath'] == UPDATE_RAW_PATH:
        
        try:
        
            username = event['queryStringParameters']['username']
            new_username = event['queryStringParameters']['new_username']
            cursor.execute("UPDATE USERS  SET username = (%s) WHERE username = (%s)", (new_username, username))
            return_string = "Succesfully changed username from - " + username +" to - " + new_username 
            return {
                'statusCode' : 200,
                'body': return_string
            }
    
        except:
            return {
                'statusCode' : 200,
                'body': "The username you have entered is either wrong or doesn't exist."
            }
        
    elif event['rawPath'] == LOGIN_RAW_PATH:
        
        try:
            
            email_data = event['queryStringParameters']['email']
            password_data = event['queryStringParameters']['password']
            cursor.execute("SELECT password FROM USERS WHERE email = (%s) ", (email_data))
            rows = cursor.fetchall()
            print("THIS IS THE PASSWORD RETURNED FROM DATABASE")
            pwd_from_db = rows[0][0]
        
            if(pwd_from_db == password_data):
                
                return_string = "Login successful. Welcome back!"
                return {
                'statusCode' : 200,
                'body': return_string
                }
            
            else:
                return_string = "Incorrect password!"
                return {
                'statusCode' : 200,
                'body': return_string
                }
                
        except:
        
            return {
                'statusCode' : 200,
                'body': "The username you entered is either incorrect or doesn't exist!"
            }